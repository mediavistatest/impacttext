// script.js



    // create the module and name it scotchApp

        // also include ngRoute for all our routing needs

    var superAdmin = angular.module('superAdmin', ['ngRoute', 'ui.bootstrap', 'ngGrid', 'cgNotify', 'ngCookies']);



    



    