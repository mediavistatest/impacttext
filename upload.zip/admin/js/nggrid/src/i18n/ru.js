window.ngGrid.i18n['ru'] = {
    ngAggregateLabel: 'записи',
    ngGroupPanelDescription: 'Перетащите сюда заголовок колонки для группировки по этой колонке.',
    ngSearchPlaceHolder: 'Искать...',
    ngMenuText: 'Выберите столбцы:',
    ngShowingItemsLabel: 'Показаны записи:',
    ngTotalItemsLabel: 'Всего записей:',
    ngSelectedItemsLabel: 'Выбранные записи:',
    ngPageSizeLabel: 'Строк на странице:',
    ngPagerFirstTitle: 'Первая страница',
    ngPagerNextTitle: 'Следующая страница',
    ngPagerPrevTitle: 'Предыдущая страница',
    ngPagerLastTitle: 'Последняя страница'
};